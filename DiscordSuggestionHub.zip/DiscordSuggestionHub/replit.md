# Discord Suggestion Bot

## Overview

This is a Discord bot designed to manage suggestions for a Discord server. The bot allows users to submit suggestions through slash commands, handles voting on suggestions through reactions, and creates staff tickets for suggestion management. The bot is built using discord.py with a focus on slash commands and reaction-based voting.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The bot follows a modular architecture with clear separation of concerns:

- **Configuration Management**: Centralized configuration using environment variables
- **Command System**: Discord slash commands for user interactions
- **Event Handling**: Reaction-based voting system with automatic validation
- **Utility Functions**: Reusable embed creation and formatting utilities

## Key Components

### Configuration (`config.py`)
- Environment variable management with validation
- Channel ID configuration for suggestions and staff channels
- Error handling and logging for missing configuration

### Bot Core (`main.py`)
- Main bot class extending discord.py commands.Bot
- Logging configuration with both file and console output
- Bot initialization with required intents (message content, reactions)

### Command System (`bot/commands.py`)
- Slash command `/suggestion` for submitting suggestions
- Input validation (title ≤ 100 chars, description ≤ 1000 chars)
- Automatic embed creation and posting to suggestion channel

### Event Handlers (`bot/handlers.py`)
- Reaction-based voting system (👍/👎 only)
- Automatic removal of opposite reactions (prevents double voting)
- Logging of voting activities

### utilities (`bot/utils.py`)
- Embed creation functions for suggestions and tickets
- Consistent styling and formatting across the bot
- Timestamp and author information embedding

## Data Flow

1. **Suggestion Submission**:
   - User invokes `/suggestion` slash command
   - Bot validates input parameters
   - Creates formatted embed with suggestion details
   - Posts to configured suggestion channel
   - Adds initial voting reactions

2. **Voting Process**:
   - Users react with 👍 or 👎 to vote
   - Bot removes invalid reactions (not thumbs up/down)
   - Prevents double voting by removing opposite reactions
   - Logs voting activities

3. **Staff Management**:
   - Staff channel configuration for ticket creation
   - Embed utilities prepared for staff notification system

## External Dependencies

- **discord.py**: Primary Discord API wrapper
- **python-dotenv**: Environment variable management
- **asyncio**: Asynchronous programming support
- **logging**: Built-in Python logging for debugging and monitoring

## Deployment Strategy

The bot is designed for simple deployment with:

- Environment variable configuration (.env file support)
- File-based logging (bot.log)
- Docker-ready structure with minimal dependencies
- Graceful error handling for missing configuration

### Required Environment Variables:
- `DISCORD_TOKEN`: Bot token from Discord Developer Portal
- `SUGGESTION_CHANNEL_ID`: Channel for posting suggestions
- `STAFF_CHANNEL_ID`: Channel for staff tickets

### Optional Configuration:
- `APPROVED_CHANNEL_ID`: Channel for approved suggestions (10+ upvotes)
- `APPROVED_ROLE_ID`: Role to mention when suggestions are approved
- `BOT_PREFIX`: Command prefix (default: "!")
- `LOG_LEVEL`: Logging level (default: "INFO")

The bot includes comprehensive error handling and will warn about missing optional configuration while failing gracefully on missing required configuration.

## Recent Changes: Latest modifications with dates

### 2025-07-14: Advanced Poll System with Vote Tracking and Editing
- **Optional Parameters**: Poll options parameter is now truly optional, defaults to "Yes, No"
- **Vote Tracking**: `/pollresults` now shows who voted for each option
- **Poll Editing**: New `/editpoll` command for modifying active polls
- **Creator Control**: Only poll creators or admins can edit polls
- **Extended Duration**: Poll duration now supports up to 7 days (168 hours)
- **Smart Emoji Selection**: Auto-uses ✅/❌ for 2-option polls, numbered emojis for 3+
- **Custom Emojis**: Optional emoji parameter for personalized poll reactions
- **Role-Based Voting**: Restrict poll voting to specific roles only
- **Visual Results**: Progress bars and percentage displays in results
- **Smart Vote Management**: Single-choice voting with automatic duplicate removal

### 2025-07-14: Added Auto-Approval System
- **Auto-Approval**: Suggestions with 10+ upvotes automatically posted to approved channel
- **Role Mention**: Configurable role gets mentioned when suggestions are approved
- **Visual Indicators**: ✅ reaction added to approved suggestions
- **New Configuration**: Added approved channel and role settings to `/config`
- **Updated Status**: `/status` command now shows all 4 configured channels/roles

### 2025-07-14: Enhanced Configuration System
- **Dynamic Configuration**: `/config` command allows real-time channel/role updates
- **Status Dashboard**: `/status` command shows current bot configuration
- **Admin Controls**: Configuration commands restricted to administrators
- **Validation**: Automatic verification of channel and role existence